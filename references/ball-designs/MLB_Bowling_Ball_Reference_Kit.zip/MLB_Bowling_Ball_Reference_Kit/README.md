# MLB Bowling Ball — Image Reference Kit

**All 30 current MLB teams • 30 primary logo links • 60 direct official cap/wordmark SVG links • 150 specifically curated reference-image searches (5/team).**

## Start here

- **`gallery.html`**: open in a browser. It displays the **real primary ESPN logo** for each team and the **real official MLB cap and wordmark SVGs**. For five additional themes per team — historical marks, mascots, stadium architecture, team imagery — choose **Find source photos**, which opens the corresponding Wikimedia Commons image search. This gallery works without running a script, as long as you have internet access.
- **`reference_catalog.csv`**: a spreadsheet-friendly list of **240 references and their actual source/image-search URLs**.
- **`teams.json`**: full machine-readable teams and 2026 branding references, if you're making custom bowling-ball designs programmatically.
- **`download_all.py`**: OPTIONAL downloader (requires a Mac/Windows/Linux computer with Python and internet). It attempts to save a primary logo PNG, two official cap/wordmark PNGs (plus original SVGs), and **five further photographs/graphic references as PNGs** for each team. Results depend on availability. It also generates team contact sheets, `download_manifest.csv`, and an updated `gallery.html` with locally saved images.

**Important:** This ZIP contains the catalog, source links, live online preview, and downloader. It does **not** already include the original PNG image files. Those can be obtained through the linked third-party full-logo ZIP, the provided download scripts, or by opening source links. This is not an automatically completed 240-image archive.

## Ready-made current MLB logo ZIP (separate download)

This independent public repository already offers a **5.3 MB collection of all 30 current MLB teams, with 6 PNG variants per team** (128px and 512px, including circular and square transparent versions), **plus 26 genuine SVG logos**:

https://github.com/frertommy/team-logos/blob/main/downloads/MLB.zip

Open that page and click **View raw / Download raw file**. The circular versions work especially well for bowling-ball mockups; use the SVG when available for sharper printing.

## Bulk download on a computer

1. Extract this ZIP to a normal writable folder.
2. **Windows:** double-click `START_WINDOWS.bat` (requires Python from python.org). **Mac/Linux:** open a terminal in the extracted folder and run `sh START_MAC_LINUX.sh`.
3. When finished, open `gallery.html`; saved images are under `assets/<Team>/` and a credit/source list is in `download_manifest.csv`. Team contact sheets are `00_CONTACT_SHEET.png` files.
4. If you only want a single team, run `python download_all.py --team TB` or `python download_all.py --team Yankees`.
5. For two additional official mark PNGs per team, install optional SVG rendering support: `python -m pip install cairosvg` (Cairo dependencies may be needed on some operating systems). If not installed, the script still saves MLB SVGs and the main PNGs, but official variant PNGs cannot be rendered.

**Wikimedia Commons note:** Search is programmatic and may not find a good photo for every specific subject. Missing items remain source links; the script does not fabricate images or claim that the requested subject was found. Review every image in `gallery.html` before production. Photo licenses are stored in the manifest where provided by Commons.

## Designed for custom bowling-ball graphics

This reference kit intentionally includes **primary team branding, caps/wordmarks, vintage imagery, mascots, signature ballpark details, and local landmarks**. For print applications, prefer clean vector marks or high-resolution transparent logos over upscaled small screenshots. A photo converted to PNG remains a rectangular photo with its original background; conversion does **not** make the background transparent.

## Rights and source notes

- Primary team-mark previews: ESPN MLB logo assets (`a.espncdn.com`).
- Official current cap and wordmark vectors: MLB team logo endpoints (`www.mlbstatic.com`).
- Historical/mascot/ballpark image discovery: Wikimedia Commons (`commons.wikimedia.org`).
- Additional logo-history browsing: https://sportslogohistory.com/mlb-alternate-logo/

MLB marks, mascots, and team names are owned by their respective rights holders. Wikimedia Commons images also have individual license requirements (often attribution/share-alike). **The images are for design reference; their presence does not authorize commercial printing or sales of branded bowling balls.** Check licensing and attribution with the rights holder and bowling-ball manufacturer before production.

All asset links are external and might change after November 2026. This pack is an independent, unofficial reference catalog.
