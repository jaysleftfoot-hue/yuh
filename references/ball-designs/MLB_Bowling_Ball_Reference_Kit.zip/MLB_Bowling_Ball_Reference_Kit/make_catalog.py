import json, csv, urllib.parse
from pathlib import Path
D=Path(__file__).resolve().parent
# Five distinct, manually curated design motifs per current MLB club.
# Categories are a deliberate mix of logos, mascots, stadium architecture and local identity.
T=[
('ARI','Arizona Diamondbacks','NL West','ari',[('Alternate logo','Snake-head A cap insignia'),('Throwback','Purple and teal 1998 diamondback snake branding'),('Mascot','D Baxter the Bobcat mascot'),('Ballpark','Chase Field swimming pool'),('Ballpark detail','Chase Field retractable roof and desert views')]),
('ATL','Atlanta Braves','NL East','atl',[('Alternate logo','Script A and tomahawk logo'),('Throwback','Vintage Braves feather sleeve patch'),('Mascot','Blooper Braves mascot'),('Ballpark','Truist Park right field Chop House'),('Landmark','The Battery Atlanta outside Truist Park')]),
('BAL','Baltimore Orioles','AL East','bal',[('Alternate logo','Cartoon Orioles bird head cap logo'),('Throwback','Vintage Baltimore Orioles smiling bird logo'),('Mascot','The Oriole Bird mascot'),('Ballpark','Oriole Park at Camden Yards brick warehouse'),('Ballpark detail','Camden Yards Eutaw Street baseball plaques')]),
('BOS','Boston Red Sox','AL East','bos',[('Alternate logo','Red Sox hanging red socks emblem'),('Throwback','Boston Red Sox vintage red B cap insignia'),('Mascot','Wally the Green Monster mascot'),('Ballpark','Fenway Park Green Monster scoreboard'),('Ballpark detail','Fenway Park Pesky Pole')]),
('CHC','Chicago Cubs','NL Central','chc',[('Alternate logo','Chicago Cubs walking bear logo'),('Throwback','Chicago Cubs vintage bear head emblem'),('Mascot','Clark the Cub mascot'),('Ballpark','Wrigley Field red marquee entrance'),('Ballpark detail','Wrigley Field ivy outfield wall')]),
('CHW','Chicago White Sox','AL Central','chw',[('Alternate logo','Chicago White Sox black Sox script cap logo'),('Throwback','Chicago White Sox 1980s batter logo'),('Mascot','Southpaw Chicago White Sox mascot'),('Ballpark','Rate Field pinwheel scoreboard'),('Ballpark detail','Old Comiskey Park exploding scoreboard')]),
('CIN','Cincinnati Reds','NL Central','cin',[('Alternate logo','Cincinnati Reds wishbone C insignia'),('Throwback','Cincinnati Reds vintage Mr Redlegs face logo'),('Mascot','Mr Redlegs mascot'),('Ballpark','Great American Ball Park smokestacks'),('Ballpark detail','Great American Ball Park Ohio River riverboat views')]),
('CLE','Cleveland Guardians','AL Central','cle',[('Alternate logo','Cleveland Guardians diamond C cap logo'),('Alternate logo','Cleveland Guardians Fastball G wing logo'),('Mascot','Slider Cleveland Guardians mascot'),('Ballpark','Progressive Field scoreboard baseball stadium'),('Landmark','Guardians of Traffic statues Hope Memorial Bridge')]),
('COL','Colorado Rockies','NL West','col',[('Alternate logo','Colorado Rockies interlocking CR cap logo'),('Throwback','Colorado Rockies purple mountain baseball emblem'),('Mascot','Dinger Colorado Rockies dinosaur mascot'),('Ballpark','Coors Field brick stadium exterior'),('Ballpark detail','Coors Field Rockies skyline mountains')]),
('DET','Detroit Tigers','AL Central','det',[('Alternate logo','Detroit Tigers old English D insignia'),('Throwback','Vintage Detroit Tigers leaping tiger emblem'),('Mascot','Paws Detroit Tigers mascot'),('Ballpark','Comerica Park tiger statues entrance'),('Ballpark detail','Comerica Park tiger carousel')]),
('HOU','Houston Astros','AL West','hou',[('Alternate logo','Houston Astros H star insignia'),('Throwback','Houston Astros rainbow tequila sunrise logo'),('Mascot','Orbit Astros green mascot'),('Ballpark','Daikin Park left field locomotive train'),('Ballpark detail','Astros home ballpark train and outfield wall')]),
('KC','Kansas City Royals','AL Central','kc',[('Alternate logo','Kansas City Royals KC crown insignia'),('Throwback','Kansas City Royals classic golden crown logo'),('Mascot','Sluggerrr Kansas City Royals mascot'),('Ballpark','Kauffman Stadium outfield fountains'),('Ballpark detail','Kauffman Stadium crown scoreboard')]),
('LAA','Los Angeles Angels','AL West','laa',[('Alternate logo','Los Angeles Angels halo A cap insignia'),('Throwback','California Angels winged A historic logo'),('Team symbol','Los Angeles Angels Rally Monkey'),('Ballpark','Angel Stadium giant red baseball caps entrance'),('Ballpark detail','Angel Stadium center field rock pile waterfall')]),
('LAD','Los Angeles Dodgers','NL West','lad',[('Alternate logo','Los Angeles Dodgers LA cap insignia'),('Throwback','Brooklyn Dodgers historic B cap logo'),('Team symbol','Los Angeles Dodgers baseball flying logo'),('Ballpark','Dodger Stadium palm trees aerial view'),('Landmark','Dodger Stadium Think Blue sign')]),
('MIA','Miami Marlins','NL East','mia',[('Alternate logo','Miami Marlins stylized M fish cap logo'),('Throwback','Florida Marlins teal jumping marlin 1993 logo'),('Mascot','Billy the Marlin mascot'),('Ballpark','loanDepot park former home run sculpture'),('Ballpark detail','loanDepot park retractable roof and aquarium')]),
('MIL','Milwaukee Brewers','NL Central','mil',[('Alternate logo','Milwaukee Brewers ball in glove logo'),('Throwback','Milwaukee Brewers vintage Barrelman logo'),('Mascot','Bernie Brewer mascot'),('Ballpark','American Family Field Bernie Brewer slide'),('Ballpark detail','American Family Field fan shaped retractable roof')]),
('MIN','Minnesota Twins','AL Central','min',[('Alternate logo','Minnesota Twins Minnie and Paul shaking hands emblem'),('Throwback','Minnesota Twins vintage TC cap logo'),('Mascot','TC Bear Minnesota Twins mascot'),('Ballpark','Target Field Minnie and Paul home run sign'),('Ballpark detail','Target Field downtown Minneapolis skyline')]),
('NYM','New York Mets','NL East','nym',[('Alternate logo','New York Mets orange NY insignia'),('Throwback','New York Mets classic skyline circle logo'),('Mascot','Mr Met mascot baseball head'),('Ballpark','Citi Field Home Run Apple'),('Ballpark detail','Citi Field Jackie Robinson Rotunda')]),
('NYY','New York Yankees','AL East','nyy',[('Alternate logo','New York Yankees interlocking NY logo'),('Throwback','Yankees top hat bat baseball crest'),('Uniform symbol','New York Yankees classic pinstripes'),('Ballpark','Yankee Stadium Monument Park'),('Ballpark detail','Yankee Stadium frieze grandstand facade')]),
('ATH','Athletics','AL West','oak',[('Alternate logo','Athletics green A apostrophe s cap insignia'),('Throwback','Oakland Athletics white elephant logo'),('Mascot','Stomper Athletics elephant mascot'),('Ballpark','Sutter Health Park Sacramento baseball stadium'),('Team symbol','Athletics gold Sacramento alternate baseball uniform')]),
('PHI','Philadelphia Phillies','NL East','phi',[('Alternate logo','Philadelphia Phillies classic red P cap insignia'),('Throwback','Philadelphia Phillies vintage red white blue bell emblem'),('Mascot','Phillie Phanatic mascot'),('Ballpark','Citizens Bank Park Liberty Bell home run sign'),('Ballpark detail','Citizens Bank Park Ashburn Alley')]),
('PIT','Pittsburgh Pirates','NL Central','pit',[('Alternate logo','Pittsburgh Pirates gold P cap insignia'),('Throwback','Pittsburgh Pirates classic pirate head emblem'),('Mascot','Pirate Parrot mascot'),('Ballpark','PNC Park Pittsburgh skyline Roberto Clemente Bridge'),('Ballpark detail','PNC Park 21 foot Clemente Wall')]),
('SD','San Diego Padres','NL West','sd',[('Alternate logo','San Diego Padres interlocking SD cap insignia'),('Throwback','San Diego Padres swinging friar retro emblem'),('Team symbol','San Diego Padres brown pinstripe uniform'),('Ballpark','Petco Park Western Metal Supply Company building'),('Ballpark detail','Petco Park Tony Gwynn statue')]),
('SF','San Francisco Giants','NL West','sf',[('Alternate logo','San Francisco Giants orange SF cap insignia'),('Throwback','San Francisco Giants vintage Giants script logo'),('Mascot','Lou Seal San Francisco Giants mascot'),('Ballpark','Oracle Park McCovey Cove kayakers'),('Ballpark detail','Oracle Park oversized baseball glove Coca Cola bottle')]),
('SEA','Seattle Mariners','AL West','sea',[('Alternate logo','Seattle Mariners compass rose logo'),('Throwback','Seattle Mariners vintage gold trident M emblem'),('Mascot','Mariner Moose Seattle Mariners mascot'),('Ballpark','T Mobile Park retractable roof'),('Ballpark detail','T Mobile Park compass rose rotunda')]),
('STL','St. Louis Cardinals','NL Central','stl',[('Alternate logo','St Louis Cardinals interlocking STL cap insignia'),('Throwback','St Louis Cardinals pair of redbirds on bat logo'),('Mascot','Fredbird St Louis Cardinals mascot'),('Ballpark','Busch Stadium Gateway Arch skyline'),('Ballpark detail','Busch Stadium Stan Musial statue')]),
('TB','Tampa Bay Rays','AL East','tb',[('Alternate logo','Tampa Bay Devil Rays original rainbow manta ray logo'),('Throwback','Tampa Bay Devil Rays purple green retro baseball logo'),('Mascot','Raymond Tampa Bay Rays mascot'),('Ballpark','Tropicana Field white dome roof'),('Team symbol','Tampa Bay Rays cowbell fans')]),
('TEX','Texas Rangers','AL West','tex',[('Alternate logo','Texas Rangers blue red T cap emblem'),('Throwback','Texas Rangers retro sheriff star logo'),('Mascot','Rangers Captain mascot horse'),('Ballpark','Globe Life Field Arlington retractable roof'),('Ballpark detail','Globe Life Field baseball statues fan sculpture')]),
('TOR','Toronto Blue Jays','AL East','tor',[('Alternate logo','Toronto Blue Jays red maple leaf bird emblem'),('Throwback','Toronto Blue Jays 1990s split bird baseball logo'),('Mascot','Ace Toronto Blue Jays mascot'),('Ballpark','Rogers Centre Toronto CN Tower view'),('Ballpark detail','Rogers Centre open roof baseball stadium')]),
('WSH','Washington Nationals','NL East','wsh',[('Alternate logo','Washington Nationals curly W cap logo'),('Throwback','Washington Nationals DC interlocking alternate logo'),('Mascot','Screech Washington Nationals eagle mascot'),('Ballpark','Nationals Park Washington Capitol skyline'),('Ballpark detail','Nationals Park racing presidents mascots')]),
]
assert len(T)==30 and sum(len(t[4]) for t in T)==150
TEAM_IDS={'ARI':109,'ATL':144,'BAL':110,'BOS':111,'CHC':112,'CHW':145,'CIN':113,'CLE':114,'COL':115,'DET':116,'HOU':117,'KC':118,'LAA':108,'LAD':119,'MIA':146,'MIL':158,'MIN':142,'NYM':121,'NYY':147,'ATH':133,'PHI':143,'PIT':134,'SD':135,'SF':137,'SEA':136,'STL':138,'TB':139,'TEX':140,'TOR':141,'WSH':120}
teams=[]
for abbr,name,division,espn,refs in T:
  primary=f'https://a.espncdn.com/i/teamlogos/mlb/500/{espn}.png'
  altpage='https://sportslogohistory.com/mlb-alternate-logo/'
  rec={'abbr':abbr,'name':name,'division':division,'espn_code':espn,'primary_png_url':primary,
    'primary_alt_png_url':f'https://a.espncdn.com/i/teamlogos/mlb/500/scoreboard/{espn}.png',
    'mlb_team_id':TEAM_IDS[abbr],
    'official_mark_urls':{
      'cap':f'https://www.mlbstatic.com/team-logos/team-cap-on-light/{TEAM_IDS[abbr]}.svg',
      'wordmark':f'https://www.mlbstatic.com/team-logos/team-wordmark-on-light/{TEAM_IDS[abbr]}.svg'
    },
    'alternate_logo_gallery':altpage,'references':[]}
  for ix,(kind,motif) in enumerate(refs,1):
    query=motif
    commons='https://commons.wikimedia.org/wiki/Special:MediaSearch?type=image&search='+urllib.parse.quote(query)
    wikimedia='https://commons.wikimedia.org/w/api.php'
    rec['references'].append({'slot':ix,'category':kind,'motif':motif,'search_query':query,'commons_search_url':commons})
  teams.append(rec)
(D/'teams.json').write_text(json.dumps(teams,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with (D/'reference_catalog.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['Team','Abbr','Type','Slot','Motif','Source or search URL'])
 for t in teams:
  w.writerow([t['name'],t['abbr'],'Primary logo',0,'Primary team mark',t['primary_png_url']])
  for mark,url in t['official_mark_urls'].items():
   w.writerow([t['name'],t['abbr'],'Official '+mark,6 if mark=='cap' else 7,'Current official '+mark,url])
  for ref in t['references']:
   w.writerow([t['name'],t['abbr'],ref['category'],ref['slot'],ref['motif'],ref['commons_search_url']])
print('Built',len(teams),'teams and',sum(len(t['references']) for t in teams),'reference searches')
