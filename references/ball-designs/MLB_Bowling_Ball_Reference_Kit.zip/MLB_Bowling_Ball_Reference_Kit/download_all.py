#!/usr/bin/env python3
"""Download authentic MLB primary PNGs and 5 reference images per team.

Images are sourced from ESPN's logo CDN and Wikimedia Commons. All result file
pages, attribution, license strings and downloads are recorded in manifest.csv.
Search hits are best-effort, so ALWAYS review the generated gallery before use.
"""
from __future__ import annotations

import argparse
import csv
import html
import io
import json
import random
import re
import sys
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from threading import Lock

try:
    import requests
    from PIL import Image, ImageDraw, ImageFont, ImageOps, UnidentifiedImageError
except ImportError:
    sys.exit('Missing packages. Run: python -m pip install -r requirements.txt')

ROOT = Path(__file__).resolve().parent
DATA = json.loads((ROOT / 'teams.json').read_text(encoding='utf-8'))
OUT = ROOT / 'assets'
API = 'https://commons.wikimedia.org/w/api.php'
HEADERS = {'User-Agent':'MLB-Bowling-Ball-Reference-Kit/1.0 (personal design research; Wikimedia Commons API)',
           'Accept':'application/json, image/*;q=0.9, */*;q=0.7'}
LOCK = Lock()
TEAM_LOCKS = {t['abbr']:Lock() for t in DATA}
STOP = {'the','and','for','the','from','with','team','logo','baseball','stadium','ballpark','new','old','retro','vintage','insignia','emblem','current','classic','historic','the','sport','field','park','home','mark','outfield','club','mascot','view','red','white','black','blue','green','gold','orange','cap','patch','alternate','letter'}
BAD = {'disambiguation','advertisement','ticket','parking map','seat map','seating plan',
       'locator map','location map','map of','diagram of','world series logo','opening day logo',
       'svg icon','minor league baseball'}


def slug(s:str)->str:
    return re.sub(r'[^A-Za-z0-9]+','_',s).strip('_')


def http_get(url,params=None,timeout=20,attempts=3):
    for attempt in range(attempts):
        try:
            r=requests.get(url,params=params,headers=HEADERS,timeout=timeout)
            if r.status_code in (429,500,502,503,504):
                time.sleep((attempt+1)*2)
                continue
            r.raise_for_status()
            return r
        except requests.RequestException:
            if attempt==attempts-1:raise
            time.sleep((attempt+1)*1.2)
    raise RuntimeError(f'Unsuccessful HTTP: {url}')


def transparent_png(data:bytes,path:Path,max_edge=2200):
    """Convert actual source bytes to PNG without tracing/recreating logos."""
    with Image.open(io.BytesIO(data)) as im:
        im.load()
        if getattr(im,'n_frames',1)>1: im.seek(0)
        im=ImageOps.exif_transpose(im).convert('RGBA')
        if max(im.size)>max_edge:
            im.thumbnail((max_edge,max_edge),Image.Resampling.LANCZOS)
        path.parent.mkdir(parents=True,exist_ok=True)
        im.save(path,'PNG',optimize=True)
        return {'width':im.width,'height':im.height,'has_alpha': bool(im.getchannel('A').getextrema()[0]<255)}


def get_primary(team):
    # The 500px ESPN versions are actual team-logo assets, not generated imitations.
    p=OUT / slug(team['name']) / '01_PRIMARY_Logo.png'
    candidates=[team['primary_png_url'],team['primary_alt_png_url']]
    errors=[]
    for url in candidates:
        try:
            data=http_get(url).content
            dim=transparent_png(data,p)
            return {'team':team['name'],'abbreviation':team['abbr'],'slot':0,'category':'Primary logo',
                    'motif':'Current primary team branding','status':'downloaded',
                    'path':str(p.relative_to(ROOT)).replace('\\','/'),'source_page':url,
                    'source_image':url,'license':'MLB/team trademark — rights clearance may be required',
                    'artist':'Team/MLB/ESPN media asset',**dim}
        except (requests.RequestException,OSError,UnidentifiedImageError,RuntimeError) as exc:
            errors.append(f'{url}: {exc}')
    return {'team':team['name'],'abbreviation':team['abbr'],'slot':0,
            'category':'Primary logo','motif':'Current primary team branding',
            'status':'missing','path':'','source_page':team['primary_png_url'],
            'source_image':'','license':'','artist':'','error':' | '.join(errors)}


def get_official_mark(team, slot, kind):
    """Preserve MLB's actual vector mark AND render it to a transparent PNG."""
    url = team['official_mark_urls'][kind]
    base = OUT / slug(team['name'])
    svg_path = base / f"{slot+1:02d}_OFFICIAL_{kind.upper()}.svg"
    png_path = svg_path.with_suffix('.png')
    rec={'team':team['name'],'abbreviation':team['abbr'],'slot':slot,
         'category':'Official '+kind,'motif':f'Official team {kind} logo',
         'source_page':url,'source_image':url,
         'license':'MLB team trademark — rights clearance may be required',
         'artist':'MLB Advanced Media'}
    try:
        content = http_get(url).content
        if b'<svg' not in content[:2000].lower():
            raise ValueError('Expected SVG, received other content')
        svg_path.parent.mkdir(parents=True,exist_ok=True)
        svg_path.write_bytes(content)
        try:
            import cairosvg
            png_data=cairosvg.svg2png(bytestring=content,output_width=1200)
            dim=transparent_png(png_data,png_path)
            return {**rec,'status':'downloaded','path':str(png_path.relative_to(ROOT)).replace('\\','/'),**dim}
        except (ImportError,OSError,Exception) as exc:
            return {**rec,'status':'SVG saved; PNG unavailable','path':'',
                    'source_file':str(svg_path.relative_to(ROOT)).replace('\\','/'),
                    'error':'SVG downloaded successfully; local SVG renderer unavailable: '+str(exc)[:160]}
    except Exception as exc:
        return {**rec,'status':'source only','path':'','error':str(exc)[:280]}


def clean_html(txt):
    return re.sub(r'<[^>]*>','',html.unescape(txt or '')).strip()


def distinct_tokens(q):
    return [t.lower() for t in re.findall(r'[A-Za-z0-9]+',q)
            if len(t)>2 and t.lower() not in STOP]


def image_search(query,used_urls,team_name=''):
    """Grounded search via Commons MediaWiki File namespace; no generative image results."""
    chosen=None
    search_terms=[query]
    # Broaden overly specific queries if Commons has few or no files.
    parts=query.split(' ')
    if len(parts)>5:
        search_terms.append(' '.join(parts[-5:]))
    for search_str in search_terms:
        try:
            params={'action':'query','generator':'search','gsrsearch':search_str,
                    'gsrnamespace':6,'gsrlimit':20,'prop':'imageinfo',
                    'iiprop':'url|mime|size|extmetadata','iiurlwidth':2000,
                    'format':'json','formatversion':2,'origin':'*'}
            pages=http_get(API,params=params).json().get('query',{}).get('pages',[])
        except Exception:
            continue
        relevant=[]
        tokens=distinct_tokens(query)
        team_words=set(distinct_tokens(team_name))
        motif_tokens=[t for t in tokens if t not in team_words]
        for p in pages:
            if not p.get('imageinfo'):continue
            info=p['imageinfo'][0]
            mime=(info.get('mime') or '').lower()
            if not mime.startswith('image/'): continue
            if mime in ('image/tiff','image/x-tiff','image/vnd.djvu'):continue
            title=p.get('title','')
            lower=title.lower().replace('_',' ')
            if any(b in lower for b in BAD):continue
            original=info.get('url','')
            url=info.get('thumburl') or original
            if not url or original in used_urls:continue
            # A small match score prioritizes identifiable subjects over broad results.
            matches=sum(1 for t in tokens if t in lower)
            specific_matches=sum(1 for t in motif_tokens if t in lower)
            specificity=(matches/max(len(tokens),1))
            # Do not accept a generic photo that only names the club.
            if matches==0 or (motif_tokens and specific_matches==0):continue
            width,height=info.get('width',0),info.get('height',0)
            if width and height and (width<160 or height<130):continue
            if p.get('title','').lower().endswith(('.ogg','.pdf','.webm')):continue
            meta=info.get('extmetadata',{})
            license_txt=clean_html((meta.get('LicenseShortName') or {}).get('value',''))
            author=clean_html((meta.get('Artist') or {}).get('value',''))[:350]
            score=10*specificity + (2 if len(tokens)>1 and tokens[-1] in lower else 0)
            score+=0.4 if width>800 else 0
            if 'svg' in mime and ('logo' in query.lower() or 'emblem' in query.lower()):score+=0.7
            relevant.append((score,{'file_title':title,'source_page':info.get('descriptionurl',''),
                      'source_image':url,'original_image':original,
                      'license':license_txt,'artist':author,'width_source':width,
                      'height_source':height}))
        relevant.sort(key=lambda x:x[0],reverse=True)
        if relevant:
            chosen=relevant[0][1]
            break
    return chosen


def get_reference(team, ref, used_global):
    slot=ref['slot']
    base={'team':team['name'],'abbreviation':team['abbr'],'slot':slot,
          'category':ref['category'],'motif':ref['motif']}
    # Reserve image sources across one team so the same image cannot appear twice.
    try:
        with TEAM_LOCKS[team['abbr']]:
            with LOCK:
                used=set(used_global.get(team['abbr'],set()))
            candidate=image_search(ref['search_query'],used,team['name'])
            if candidate:
                # Reserve before downloads, preventing duplicate choices in concurrent jobs.
                with LOCK:
                    used_global.setdefault(team['abbr'],set()).add(candidate['original_image'])
        if candidate is None:
            return {**base,'status':'search only','path':'',
                    'source_page':ref['commons_search_url'],'source_image':'',
                    'license':'See individual source','artist':'','error':'No suitable Commons file found'}
        image_url=candidate['source_image']
        path=OUT / slug(team['name']) / f"{slot+1:02d}_{slug(ref['category'])}_{slug(ref['motif'])[:48]}.png"
        data=http_get(image_url,timeout=35).content
        dim=transparent_png(data,path)
        return {**base,'status':'downloaded','path':str(path.relative_to(ROOT)).replace('\\','/'),
                'source_page':candidate['source_page'],'source_image':candidate['source_image'],
                'source_file':candidate['file_title'],'license':candidate['license'],
                'artist':candidate['artist'],**dim}
    except Exception as exc:
        return {**base,'status':'search only','path':'',
                'source_page':ref['commons_search_url'],'source_image':'',
                'license':'See individual source','artist':'','error':str(exc)[:300]}


def render_gallery(rows):
    """Local-first gallery that still functions before the downloader is executed."""
    indexed={(r['abbreviation'],int(r['slot'])):r for r in rows}
    cards=[]
    for t in DATA:
        refs=[]
        # Always show the real ESPN CDN primary logo even before local downloads.
        first=indexed.get((t['abbr'],0),{})
        refs.append({'kind':'Primary logo','motif':'Primary team mark',
                     'image':first.get('path') or t['primary_png_url'],
                     'url':first.get('source_page') or t['primary_png_url'],
                     'downloaded':bool(first.get('path')), 'status':first.get('status','online preview')})
        for slot,kind in [(6,'cap'),(7,'wordmark')]:
            row=indexed.get((t['abbr'],slot),{})
            refs.append({'kind':'Official '+kind,'motif':'Current official '+kind+' mark',
                         'image':row.get('path') or t['official_mark_urls'][kind],
                         'url':row.get('source_page') or t['official_mark_urls'][kind],
                         'downloaded':bool(row.get('path')),
                         'status':row.get('status','online preview')})
        for r in t['references']:
            row=indexed.get((t['abbr'],r['slot']),{})
            refs.append({'kind':r['category'],'motif':r['motif'],
                         'image':row.get('path',''),
                         'url':row.get('source_page') or r['commons_search_url'],
                         'downloaded':bool(row.get('path')),
                         'status':row.get('status','source search')})
        cards.append({'abbr':t['abbr'],'name':t['name'],'division':t['division'],'refs':refs})
    payload=json.dumps(cards,ensure_ascii=False).replace('</','<\\/')
    template=(ROOT/'gallery_template.html').read_text(encoding='utf-8')
    (ROOT/'gallery.html').write_text(template.replace('/*__DATA__*/',payload),encoding='utf-8')


def make_contact_sheet(team,rows):
    subset=[r for r in rows if r['abbreviation']==team['abbr'] and r.get('path')]
    if not subset:return
    W,H=1800,1240
    sheet=Image.new('RGB',(W,H),'#0f1722')
    draw=ImageDraw.Draw(sheet)
    try: font=ImageFont.truetype('DejaVuSans.ttf',28)
    except OSError:font=ImageFont.load_default()
    try: big=ImageFont.truetype('DejaVuSans-Bold.ttf',47)
    except OSError:big=font
    draw.text((55,28),team['name'],font=big,fill='#f3f5f7')
    draw.text((57,93),'BOWLING BALL REFERENCE BOARD | Source photos + authentic team marks',font=font,fill='#9ca5b6')
    for r in subset:
        n=int(r['slot']); col=n%4; row=n//4
        x=47+col*441;y=150+row*535
        draw.rounded_rectangle((x,y,x+417,y+510),radius=18,fill='#202e3c')
        try:
            with Image.open(ROOT/r['path']) as src:
                im=src.convert('RGBA'); im.thumbnail((375,390),Image.Resampling.LANCZOS)
                px=x+(417-im.width)//2;py=y+12+(410-im.height)//2
                sheet.paste(im,(px,py),im)
        except Exception:pass
        label=('PRIMARY LOGO' if n==0 else f'{n:02d} · {r["category"].upper()}')
        draw.text((x+20,y+430),label,font=font,fill='#f3f5f7')
        if n==0: detail=''
        else: detail=(r['motif'][:39]+'…') if len(r['motif'])>39 else r['motif']
        draw.text((x+20,y+460),detail,font=ImageFont.load_default(),fill='#b6c2d2')
    folder=OUT/slug(team['name']);folder.mkdir(parents=True,exist_ok=True)
    sheet.save(folder/'00_CONTACT_SHEET.png',optimize=True)


def save_manifest(rows):
    fields=['team','abbreviation','slot','category','motif','status','path',
            'source_page','source_image','source_file','artist','license','width','height','has_alpha','error']
    with (ROOT/'download_manifest.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
    successes=sum(x['status']=='downloaded' for x in rows)
    report={'teams':len(DATA),'requested_primary_logos':30,'requested_extra_refs':150,'requested_official_cap_wordmark':60,
            'successes':successes,'missing':len(rows)-successes,
            'note':'All images require user review; Commons search ranking is automated.',
            'manifest':'download_manifest.csv'}
    (ROOT/'download_report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return successes


def main():
    ap=argparse.ArgumentParser(description='Download current MLB logos plus 5 curated reference motifs per club')
    ap.add_argument('--dry-run',action='store_true',help='Create gallery and catalog without downloading images')
    ap.add_argument('--team',default='',help='One team by abbreviation or a portion of its name; e.g. TB or Rays')
    ap.add_argument('--workers',type=int,default=3,help='Max simultaneous Commons queries (default 3)')
    args=ap.parse_args()
    teams=DATA
    if args.team:
        query=args.team.lower()
        teams=[x for x in DATA if query==x['abbr'].lower() or query in x['name'].lower()]
        if not teams:sys.exit(f'No matching team: {args.team}')
    if args.dry_run:
        render_gallery([])
        print('Prepared gallery.html and reference_catalog.csv. Open gallery.html in a web browser.')
        return
    OUT.mkdir(exist_ok=True)
    old=[]
    existing=ROOT/'download_manifest.csv'
    if existing.exists():
        with existing.open('r',encoding='utf-8-sig',newline='') as f:
            old=[r for r in csv.DictReader(f) if r.get('path') and (ROOT/r['path']).exists()]
    rows={(r['abbreviation'],int(r['slot'])):r for r in old}
    used={}
    print(f'Collecting primary logos for {len(teams)} MLB teams...')
    for t in teams:
        key=(t['abbr'],0)
        if key in rows:continue
        r=get_primary(t);rows[key]=r
        print(f"  {t['abbr']:3} primary: {r['status']}",flush=True)
    print('Collecting MLB-provided official cap and wordmark SVG assets...')
    for t in teams:
        for slot,kind in [(6,'cap'),(7,'wordmark')]:
            key=(t['abbr'],slot)
            if key not in rows:
                rows[key]=get_official_mark(t,slot,kind)
            print(f"  {t['abbr']} {kind}: {rows[key]['status']}",flush=True)
    print('Searching Wikimedia Commons for the five reference motifs per team...')
    futures={}
    with ThreadPoolExecutor(max_workers=max(1,min(5,args.workers))) as pool:
        for t in teams:
            for r in t['references']:
                key=(t['abbr'],r['slot'])
                if key not in rows:
                    futures[pool.submit(get_reference,t,r,used)]=key
        completed=0
        for fut in as_completed(futures):
            key=futures[fut]
            try: value=fut.result()
            except Exception as ex:
                value={'team':key[0],'abbreviation':key[0],'slot':key[1],
                       'category':'Reference','motif':'','status':'search only','path':'',
                       'error':str(ex),'source_page':'','source_image':''}
            rows[key]=value; completed+=1
            print(f"  {key[0]} ref {key[1]}: {value['status']} ({completed}/{len(futures)})",flush=True)
    ordered=[]
    for t in DATA:
        if t in teams:
            ordered.extend(rows.get((t['abbr'],slot),{}) for slot in range(8))
        else:
            # Preserve previously downloaded entries from other teams.
            ordered.extend(rows.get((t['abbr'],slot),{}) for slot in range(8) if (t['abbr'],slot) in rows)
    ordered=[x for x in ordered if x]
    for t in teams:
        try: make_contact_sheet(t,ordered)
        except Exception as exc:print(f"  {t['abbr']} contact sheet error: {exc}")
    success=save_manifest(ordered)
    render_gallery(ordered)
    print(f'Done. Downloaded {success}/{len(ordered)} assets. Open gallery.html to review and click sources.')
    print('The source list and license information are in download_manifest.csv.')

if __name__=='__main__':main()
