@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo Python was not found. Install Python from python.org and try again.
  pause
  exit /b 1
)
py download_all.py
pause
